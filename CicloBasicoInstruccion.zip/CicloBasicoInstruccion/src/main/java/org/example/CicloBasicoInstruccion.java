package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class CicloBasicoInstruccion {
    private final List<Map<String, String>> memoria;
    private String pc, mar, mdr, icr, alu, unidadControl, acumulador;
    public CicloBasicoInstruccion() {
        this.memoria = new ArrayList<>();
    }

    public List<String> leerArchivo(String nombreArchivo) {
        List<String> instrucciones = new ArrayList<>();
        try {
            File archivo = new File(nombreArchivo);
            Scanner scanner = new Scanner(archivo);
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine().trim();
                instrucciones.add(linea);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("El archivo '" + nombreArchivo + "' no existe.");
        }
        return instrucciones;
    }

    public void procesarInstrucciones(List<String> instrucciones) {
        String[] linea;
        for (String instruccion: instrucciones) {
            linea = instruccion.split(" ");
            switch (linea[0]) {
                case "SET":
                    this.set(linea[1], linea[2]);
                    break;
                case "ADD":
                    this.add(linea[1], linea[2], linea[3]);
                    break;
                case "LDR":
                    this.load(linea[1]);
                    break;
                case "STR":
                    this.store(linea[1]);
                    break;
                case "SHW":
                    this.show();
                    break;
                case "END":
                    this.end();
                    break;
                default:
                    System.out.println("Instruccion erronea");
                    break;
            }
        }
    }

    private void procesar(String tipoInstruccion, String memoria) {
        this.pc = memoria;
        this.mar = this.pc;
        System.out.println(tipoInstruccion + " " + this.mar);
        this.mdr = tipoInstruccion + " " + this.mar;
        this.icr = this.mdr;
        this.unidadControl = this.icr;
        this.mar = memoria;
        if (Objects.equals(tipoInstruccion, "STORE")) {
            this.mdr = String.valueOf(this.acumulador);

            for (Map<String, String> elemento : this.memoria) {
                if (elemento.containsKey(this.mar))
                    elemento.put(this.mar, this.mdr);

                if (elemento.containsKey(this.mar)) {
                    mdr = elemento.get(this.mar);
                    break;
                }
            }
        }
        for (Map<String, String> elemento : this.memoria) {
            if (elemento.containsKey(this.mar)) {
                mdr = elemento.get(this.mar);
                break;
            }
        }
        System.out.println(this.mdr);

    }

    private void set(String memoria, String valor) {
        boolean existeMemoria = false;
        for (Map<String, String> elemento: this.memoria) {
            existeMemoria = elemento.containsKey(memoria);
        }
        if (!existeMemoria) {
            Map<String, String> nuevoElemento = new HashMap<>();
            nuevoElemento.put(memoria, valor);
            this.memoria.add(nuevoElemento);
            System.out.println(this.memoria);
        }
    }

    private void load(String valor) {
        this.procesar("LOAD", valor);
        this.acumulador = this.mdr;
        System.out.println("Este es el acumulador" + this.acumulador);
    }

    private void add(String memoria1, String memoria2, String memoria3) {
        if (Objects.equals(memoria2, "NULL") && Objects.equals(memoria3, "NULL")) {
            this.procesar("ADD", memoria1);
            this.alu = this.acumulador;
            this.acumulador = this.mdr;
            this.acumulador = String.valueOf(Integer.parseInt(this.alu) + Integer.parseInt(this.acumulador));
            System.out.println("Este es el acumulador" + this.acumulador);
        }
    }

    private void store(String valor) {
        this.procesar("STORE", valor);
    }

    private void show() {
        System.out.println("Show");
    }

    private void pause() {
        System.out.println("s");
    }

    private void decrement() {
        System.out.println("Decrement");
    }

    private void increment() {
        System.out.println("Increment");
    }

    private void end() {
        System.out.println("End");
        System.out.println(this.acumulador);
    }
}
