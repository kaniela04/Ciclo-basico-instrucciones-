package org.example;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        CicloBasicoInstruccion cbi = new CicloBasicoInstruccion();
        List<String> instrucciones = cbi.leerArchivo("src/main/resources/instrucciones.txt");
        if (instrucciones != null)
            cbi.procesarInstrucciones(instrucciones);
    }
}